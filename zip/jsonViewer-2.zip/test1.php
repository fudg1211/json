<?php

$a=array(a=>'sdf',b=>"sdsdfs<div></div>dfivf",c=>array(1,2,3,'http://su.bdimg.com/static/superpage/img/logo_white.png'));

$a=array($a,$a);

echo json_encode($a);

?>