<script>
window.location.href='http://wd.koudai.com/vshop/1/H5/H5GetCommonItems.php?userid=1&pageNum=0&pageSize=10&callback=jsonpcallback_1389866199855_24192697973921895&ver=201312101778';
</script>